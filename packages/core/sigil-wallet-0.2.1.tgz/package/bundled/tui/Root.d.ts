interface RootProps {
    apiPort?: number;
    authToken?: string;
}
export declare function Root({ apiPort, authToken }: RootProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Root.d.ts.map
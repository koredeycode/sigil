import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext } from 'react';
const ConfigContext = createContext({ apiPort: 7445, authToken: '' });
export function ConfigProvider({ children, apiPort, authToken }) {
    return (_jsx(ConfigContext.Provider, { value: { apiPort, authToken }, children: children }));
}
export function useConfig() {
    return useContext(ConfigContext);
}
//# sourceMappingURL=ConfigContext.js.map
import { ReactNode } from 'react';
interface ConfigContextType {
    apiPort: number;
    authToken: string;
}
export declare function ConfigProvider({ children, apiPort, authToken }: {
    children: ReactNode;
} & ConfigContextType): import("react/jsx-runtime").JSX.Element;
export declare function useConfig(): ConfigContextType;
export {};
//# sourceMappingURL=ConfigContext.d.ts.map
export interface Agent {
    id: string;
    name: string;
    pubkey: string;
    status: 'running' | 'paused';
    loop_interval: number;
    created_at: string;
}
export interface ChatMessage {
    id: number | string;
    agent_id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: string;
}
export interface ChatResponse {
    agent: string;
    response: string;
    tools: any[];
}
export interface WalletResponse {
    agent_id: string;
    balance: number;
    transactions: any[];
}
export declare class ApiClient {
    private baseUrl;
    private token;
    constructor(port: number, token: string);
    private fetch;
    getAgents(): Promise<Agent[]>;
    getAgent(id: string): Promise<Agent>;
    createAgent(name: string, intervalSeconds: number): Promise<Agent>;
    sendChat(agentId: string, message: string): Promise<ChatResponse>;
    getChats(agentId: string, limit?: number): Promise<ChatMessage[]>;
    controlAgent(agentId: string, action: 'start' | 'pause' | 'kill'): Promise<Agent>;
    getWallet(agentId: string): Promise<WalletResponse>;
    getProviders(): Promise<any[]>;
    getLogs(agentId: string, limit?: number): Promise<any[]>;
}
//# sourceMappingURL=api.d.ts.map
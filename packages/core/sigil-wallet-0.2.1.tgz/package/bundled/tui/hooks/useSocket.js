import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
const SocketContext = createContext({ socket: null, connected: false });
export function SocketProvider({ children, apiPort, authToken }) {
    const [socket, setSocket] = useState(null);
    const [connected, setConnected] = useState(false);
    useEffect(() => {
        if (!authToken)
            return;
        const socketInstance = io(`http://localhost:${apiPort}`, {
            auth: { token: authToken },
            transports: ['websocket'],
            reconnection: true,
            reconnectionAttempts: Infinity,
            reconnectionDelay: 1000,
            reconnectionDelayMax: 10000,
        });
        socketInstance.on('connect', () => {
            setConnected(true);
        });
        socketInstance.on('disconnect', () => {
            setConnected(false);
        });
        setSocket(socketInstance);
        return () => {
            socketInstance.disconnect();
        };
    }, [apiPort, authToken]);
    return (_jsx(SocketContext.Provider, { value: { socket, connected }, children: children }));
}
export function useSocket() {
    return useContext(SocketContext);
}
//# sourceMappingURL=useSocket.js.map
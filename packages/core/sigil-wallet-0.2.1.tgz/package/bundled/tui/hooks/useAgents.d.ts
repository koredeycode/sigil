export interface Agent {
    id: string;
    name: string;
    status: 'running' | 'paused';
    pubkey?: string;
    loop_interval?: number;
    prompt?: string;
    created_at?: string;
}
export declare function useAgents(): {
    agents: Agent[];
    activeAgent: Agent;
    nextAgent: () => void;
    prevAgent: () => void;
};
//# sourceMappingURL=useAgents.d.ts.map
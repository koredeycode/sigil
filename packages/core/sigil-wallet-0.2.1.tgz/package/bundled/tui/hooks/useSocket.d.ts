import { ReactNode } from 'react';
import { Socket } from 'socket.io-client';
interface SocketContextType {
    socket: Socket | null;
    connected: boolean;
}
interface SocketProviderProps {
    children: ReactNode;
    apiPort: number;
    authToken: string;
}
export declare function SocketProvider({ children, apiPort, authToken }: SocketProviderProps): import("react/jsx-runtime").JSX.Element;
export declare function useSocket(): SocketContextType;
export {};
//# sourceMappingURL=useSocket.d.ts.map
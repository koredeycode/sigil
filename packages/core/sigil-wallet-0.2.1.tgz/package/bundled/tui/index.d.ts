export { Root } from './Root.js';
export declare function startTui(apiPort: number, authToken: string): import("ink").Instance;
//# sourceMappingURL=index.d.ts.map
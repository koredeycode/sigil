import { jsx as _jsx } from "react/jsx-runtime";
import { render } from 'ink';
import { Root } from './Root.js';
render(_jsx(Root, {}));
//# sourceMappingURL=app.js.map
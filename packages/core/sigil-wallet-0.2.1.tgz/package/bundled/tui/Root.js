import { jsx as _jsx } from "react/jsx-runtime";
import { Layout } from './components/Layout.js';
import { ConfigProvider } from './context/ConfigContext.js';
import { SocketProvider } from './hooks/useSocket.js';
export function Root({ apiPort = 7445, authToken = '' }) {
    return (_jsx(ConfigProvider, { apiPort: apiPort, authToken: authToken, children: _jsx(SocketProvider, { apiPort: apiPort, authToken: authToken, children: _jsx(Layout, {}) }) }));
}
//# sourceMappingURL=Root.js.map
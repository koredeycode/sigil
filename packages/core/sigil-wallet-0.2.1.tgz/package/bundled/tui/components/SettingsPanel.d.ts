export declare function SettingsPanel(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SettingsPanel.d.ts.map
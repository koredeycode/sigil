import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import { useEffect, useState } from 'react';
const SIGIL_ART = `
 ███████╗██╗ ██████╗ ██╗██╗     
 ██╔════╝██║██╔════╝ ██║██║     
 ███████╗██║██║  ███╗██║██║     
 ╚════██║██║██║   ██║██║██║     
 ███████║██║╚██████╔╝██║███████╗
 ╚══════╝╚═╝ ╚═════╝ ╚═╝╚══════╝`;
export function Splash({ onDone }) {
    const [visible, setVisible] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => {
            setVisible(false);
            onDone();
        }, 2000);
        return () => clearTimeout(timer);
    }, [onDone]);
    if (!visible)
        return null;
    return (_jsxs(Box, { flexDirection: "column", paddingX: 2, paddingY: 1, children: [_jsx(Text, { color: "magenta", children: SIGIL_ART }), _jsxs(Box, { marginTop: 1, paddingX: 1, children: [_jsx(Text, { color: "magenta", bold: true, children: "\u2735 " }), _jsx(Text, { children: "Welcome to " }), _jsx(Text, { bold: true, children: "Sigil" }), _jsx(Text, { dimColor: true, children: " \u2014 local-first AI agents for Solana" })] })] }));
}
//# sourceMappingURL=Splash.js.map
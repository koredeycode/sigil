interface SplashProps {
    onDone: () => void;
}
export declare function Splash({ onDone }: SplashProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=Splash.d.ts.map
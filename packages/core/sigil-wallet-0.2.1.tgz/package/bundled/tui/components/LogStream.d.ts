import { Agent } from '../hooks/useAgents.js';
interface LogStreamProps {
    activeAgent: Agent | null;
}
export declare function LogStream({ activeAgent }: LogStreamProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=LogStream.d.ts.map
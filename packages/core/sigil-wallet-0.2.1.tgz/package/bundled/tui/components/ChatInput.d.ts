import { Agent } from '../hooks/useAgents.js';
export interface ChatInputProps {
    activeAgent: Agent | null;
    isFocused: boolean;
    onFocusChange?: (focused: boolean) => void;
}
export declare function ChatInput({ activeAgent, isFocused, onFocusChange }: ChatInputProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=ChatInput.d.ts.map
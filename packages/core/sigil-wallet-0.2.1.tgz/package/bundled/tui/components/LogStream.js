import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import { useEffect, useState } from 'react';
import { useSocket } from '../hooks/useSocket.js';
export function LogStream({ activeAgent }) {
    const { socket } = useSocket();
    const [logs, setLogs] = useState([]);
    useEffect(() => {
        if (!socket || !activeAgent)
            return;
        const handleThought = (data) => {
            const entry = { type: 'thought', content: data.thought, timestamp: new Date().toISOString() };
            setLogs(prev => [...prev, entry].slice(-10));
        };
        const handleAction = (data) => {
            const entry = { type: 'action', content: `${data.tool}: ${JSON.stringify(data.params)}`, timestamp: new Date().toISOString() };
            setLogs(prev => [...prev, entry].slice(-10));
        };
        // Listen to agent-specific events if namespaces work, or filter global events?
        // Socket setup in Core emits to /agent/<id> AND global.
        // Client connects to default namespace usually.
        // If we want agent specific, we check data.agent === activeAgent.id?
        // Core emits: agentIdentifier in data?
        // Let's assume global listener for now and filter.
        const filterAndAdd = (type, content, agentId) => {
            if (agentId && agentId !== activeAgent.id)
                return;
            const entry = { type, content, timestamp: new Date().toISOString() };
            setLogs(prev => [...prev, entry].slice(-10));
        };
        socket.on('agent:thought', (d) => filterAndAdd('thought', d.thought, d.agent));
        socket.on('agent:action', (d) => filterAndAdd('action', `${d.tool}`, d.agent));
        return () => {
            socket.off('agent:thought');
            socket.off('agent:action');
        };
    }, [socket, activeAgent]);
    if (!activeAgent)
        return _jsx(Box, { children: _jsx(Text, { children: "No agent selected" }) });
    return (_jsxs(Box, { borderStyle: "round", borderColor: "gray", flexDirection: "column", flexGrow: 1, paddingX: 1, children: [_jsxs(Text, { dimColor: true, children: ["--- Log Stream: ", activeAgent.name, " ---"] }), logs.length === 0 && _jsx(Text, { dimColor: true, children: "Waiting for activity..." }), logs.map((log, i) => (_jsxs(Text, { color: log.type === 'thought' ? 'yellow' : log.type === 'action' ? 'blue' : 'white', children: ["[", log.type.toUpperCase(), "] ", log.content] }, i)))] }));
}
//# sourceMappingURL=LogStream.js.map
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import TextInput from 'ink-text-input';
import { useEffect, useState } from 'react';
import { useConfig } from '../context/ConfigContext.js';
import { useSocket } from '../hooks/useSocket.js';
import { ApiClient } from '../lib/api.js';
// @ts-ignore
import md from 'cli-md';
export function ChatInput({ activeAgent, isFocused, onFocusChange }) {
    const { apiPort, authToken } = useConfig();
    const { socket } = useSocket();
    const [query, setQuery] = useState('');
    const [sending, setSending] = useState(false);
    const [dots, setDots] = useState('');
    const [messages, setMessages] = useState([]);
    useEffect(() => {
        if (!activeAgent)
            return;
        const fetchHistory = async () => {
            try {
                const client = new ApiClient(apiPort, authToken);
                const res = await client.getChats(activeAgent.id, 3);
                if (res && Array.isArray(res))
                    setMessages(res);
            }
            catch (e) { }
        };
        fetchHistory();
    }, [activeAgent, apiPort, authToken]);
    useEffect(() => {
        if (!sending)
            return;
        const timer = setInterval(() => {
            setDots((prev) => prev.length >= 3 ? '' : prev + '.');
        }, 400);
        return () => clearInterval(timer);
    }, [sending]);
    // WebSocket listener
    useEffect(() => {
        if (!socket || !activeAgent)
            return;
        const handleMessage = (data) => {
            if (data.agent === activeAgent.name) {
                setMessages(prev => {
                    const exists = prev.some(m => m.id === data.timestamp || (m.role === data.role && m.content === data.content && Date.now() - Number(m.id) < 1000));
                    if (exists && data.role === 'user')
                        return prev;
                    return [...prev, {
                            id: data.timestamp || Date.now(),
                            role: data.role,
                            content: data.content,
                            tools: data.tools
                        }];
                });
                if (data.role === 'assistant') {
                    setSending(false);
                }
            }
        };
        socket.on('chat:message', handleMessage);
        return () => {
            socket.off('chat:message', handleMessage);
        };
    }, [socket, activeAgent]);
    if (!activeAgent)
        return null;
    // Render up to last 20 messages for full-screen CLI
    const displayMsgs = messages.slice(-20);
    return (_jsxs(Box, { flexDirection: "column", gap: 1, children: [displayMsgs.length > 0 && (_jsx(Box, { flexDirection: "column", paddingX: 0, children: displayMsgs.map((msg, idx) => {
                    let parsedTools = null;
                    if (msg.tools && msg.role === 'assistant') {
                        try {
                            parsedTools = typeof msg.tools === 'string' ? JSON.parse(msg.tools) : msg.tools;
                        }
                        catch (e) { }
                    }
                    return (_jsxs(Box, { flexDirection: "column", marginBottom: msg.role === 'assistant' ? 1 : 0, children: [_jsxs(Text, { children: [msg.role === 'user' ? _jsx(Text, { color: "cyan", children: "\u276F " }) : _jsx(Text, { color: "magenta", children: "\u2735 " }), msg.role === 'user' ? msg.content : ''] }), msg.role !== 'user' && (_jsx(Text, { children: md(msg.content).trimEnd() })), parsedTools && Array.isArray(parsedTools) && parsedTools.length > 0 && (_jsxs(Box, { flexDirection: "column", paddingX: 2, borderStyle: "single", borderColor: "gray", marginY: 1, children: [_jsx(Text, { color: "gray", children: "\uD83D\uDEE0\uFE0F  Tools Executed:" }), parsedTools.map((t, i) => (_jsxs(Box, { flexDirection: "column", marginTop: i > 0 ? 1 : 0, children: [_jsxs(Text, { color: "green", children: ["\u279C ", t.tool] }), _jsx(Text, { dimColor: true, children: t.result.length > 200 ? t.result.substring(0, 200) + '...' : t.result })] }, i)))] }))] }, msg.id ?? idx));
                }) })), sending ? (_jsx(Box, { paddingX: 0, marginTop: 1, children: _jsxs(Text, { color: "yellow", children: ["\u2735 ", dots.padEnd(3, ' ')] }) })) : (_jsxs(Box, { paddingX: 0, marginTop: 1, children: [_jsx(Text, { color: "white", bold: true, children: "\u276F " }), _jsx(TextInput, { value: query, onChange: setQuery, focus: isFocused, onSubmit: async (val) => {
                            setQuery('');
                            if (!val.trim())
                                return;
                            if (socket) {
                                socket.emit('chat:message', { agentId: activeAgent.id, content: val.trim() });
                                setSending(true);
                            }
                        }, placeholder: "Type a message... (q to quit)" })] }))] }));
}
//# sourceMappingURL=ChatInput.js.map
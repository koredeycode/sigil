import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import { useEffect, useState } from 'react';
import { useConfig } from '../context/ConfigContext.js';
import { ApiClient } from '../lib/api.js';
export function Portfolio({ activeAgent }) {
    const { apiPort, authToken } = useConfig();
    const [transactions, setTransactions] = useState([]);
    useEffect(() => {
        if (!activeAgent)
            return;
        const fetchWallet = async () => {
            try {
                const client = new ApiClient(apiPort, authToken);
                const res = await client.getWallet(activeAgent.id);
                if (res && Array.isArray(res.transactions)) {
                    setTransactions(res.transactions.slice(0, 5).map((t) => ({
                        signature: (t.signature || 'Pending').substring(0, 8) + '...',
                        amount: t.amount ? t.amount.toString() : '-',
                        status: t.status || 'unknown'
                    })));
                }
            }
            catch (e) { }
        };
        fetchWallet();
    }, [activeAgent, apiPort, authToken]);
    if (!activeAgent)
        return null;
    return (_jsxs(Box, { flexDirection: "column", width: "100%", children: [_jsxs(Box, { borderStyle: "round", borderColor: "yellow", flexDirection: "column", paddingX: 1, marginBottom: 1, children: [_jsx(Text, { bold: true, underline: true, children: "Portfolio Balances" }), _jsxs(Box, { justifyContent: "space-between", children: [_jsx(Text, { children: "SOL:" }), _jsx(Text, { color: "green", children: "0.00" })] }), _jsxs(Box, { justifyContent: "space-between", children: [_jsx(Text, { children: "USDC:" }), _jsx(Text, { color: "green", children: "0.00" })] })] }), _jsx(Box, { height: 1 }), _jsx(Text, { dimColor: true, children: "--- RECENT TRANSACTIONS ---" }), transactions.length > 0 ? (_jsxs(Box, { flexDirection: "column", marginTop: 1, children: [_jsxs(Box, { flexDirection: "row", borderBottom: false, borderStyle: "single", paddingX: 1, children: [_jsx(Box, { width: "45%", children: _jsx(Text, { bold: true, children: "Signature" }) }), _jsx(Box, { width: "30%", children: _jsx(Text, { bold: true, children: "Amount" }) }), _jsx(Box, { width: "25%", children: _jsx(Text, { bold: true, children: "Status" }) })] }), transactions.map((t, idx) => (_jsxs(Box, { flexDirection: "row", borderStyle: "single", borderTop: false, borderBottom: false, paddingX: 1, children: [_jsx(Box, { width: "45%", children: _jsx(Text, { color: "gray", children: t.signature }) }), _jsx(Box, { width: "30%", children: _jsx(Text, { color: "yellow", children: t.amount }) }), _jsx(Box, { width: "25%", children: _jsx(Text, { color: t.status === 'confirmed' ? 'green' : 'orange', children: t.status }) })] }, idx))), _jsx(Box, { flexDirection: "row", borderStyle: "single", borderTop: false, height: 1 })] })) : (_jsx(Box, { marginTop: 1, children: _jsx(Text, { dimColor: true, children: "No transactions found." }) }))] }));
}
//# sourceMappingURL=Portfolio.js.map
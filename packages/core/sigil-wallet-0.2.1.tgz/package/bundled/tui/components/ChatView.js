import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import TextInput from 'ink-text-input';
import { useEffect, useState } from 'react';
// @ts-ignore
import md from 'cli-md';
// ── Single Message Renderer (used by Static) ───────────────────────────────
function renderMessage(msg) {
    // System messages (log events)
    if (msg.role === 'system') {
        return (_jsx(Box, { paddingLeft: 2, marginTop: 1, children: _jsx(Text, { dimColor: true, children: msg.content }) }));
    }
    // User messages — highlighted
    if (msg.role === 'user') {
        return (_jsxs(Box, { marginTop: 1, children: [_jsx(Text, { bold: true, color: "cyan", children: "> " }), _jsxs(Text, { bold: true, inverse: true, children: [" ", msg.content, " "] })] }));
    }
    // Assistant messages
    let parsedTools = null;
    if (msg.tools) {
        try {
            parsedTools = typeof msg.tools === 'string' ? JSON.parse(msg.tools) : msg.tools;
        }
        catch { }
    }
    return (_jsxs(Box, { flexDirection: "column", marginTop: 1, children: [_jsxs(Box, { children: [_jsx(Text, { color: "magenta", children: '● ' }), _jsxs(Text, { children: [" ", md(msg.content).trimEnd()] })] }), parsedTools && Array.isArray(parsedTools) && parsedTools.length > 0 && (_jsx(Box, { flexDirection: "column", paddingLeft: 4, children: parsedTools.map((t, i) => (_jsxs(Text, { dimColor: true, children: ["[tool] ", t.tool, t.result ? `: ${t.result.length > 120 ? t.result.substring(0, 120) + '...' : t.result}` : ''] }, i))) }))] }));
}
// ── Chat Input (self-contained state) ──────────────────────────────────────
function ChatInput({ onSubmit, isFocused, sending }) {
    const [query, setQuery] = useState('');
    const [dots, setDots] = useState('');
    useEffect(() => {
        if (!sending) {
            setDots('');
            return;
        }
        const timer = setInterval(() => {
            setDots(prev => prev.length >= 3 ? '' : prev + '.');
        }, 400);
        return () => clearInterval(timer);
    }, [sending]);
    if (sending) {
        return (_jsx(Box, { children: _jsxs(Text, { color: "magenta", children: ["  thinking", dots.padEnd(3, ' ')] }) }));
    }
    return (_jsxs(Box, { children: [_jsx(Text, { bold: true, color: "white", children: "> " }), _jsx(TextInput, { value: query, onChange: setQuery, focus: isFocused, onSubmit: (val) => {
                    setQuery('');
                    onSubmit(val);
                }, placeholder: "Type a message..." })] }));
}
export function ChatView({ singleMessage, onSubmit, isFocused = false, sending = false, inputOnly = false, }) {
    // Input mode
    if (inputOnly) {
        return _jsx(ChatInput, { onSubmit: onSubmit || (() => { }), isFocused: isFocused, sending: sending });
    }
    // Single message mode (for <Static>)
    if (singleMessage) {
        return renderMessage(singleMessage);
    }
    return null;
}
//# sourceMappingURL=ChatView.js.map
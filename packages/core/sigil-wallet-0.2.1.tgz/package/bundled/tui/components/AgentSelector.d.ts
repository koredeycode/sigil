import { Agent } from '../hooks/useAgents.js';
interface AgentSelectorProps {
    activeAgent: Agent | null;
    agents: Agent[];
}
export declare function AgentSelector({ activeAgent, agents }: AgentSelectorProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AgentSelector.d.ts.map
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import { useEffect, useState } from 'react';
import { useConfig } from '../context/ConfigContext.js';
import { useSocket } from '../hooks/useSocket.js';
import { ApiClient } from '../lib/api.js';
export function LogsView({ agentId, agentName, maxLines = 50 }) {
    const { socket } = useSocket();
    const { apiPort, authToken } = useConfig();
    const [logs, setLogs] = useState([]);
    // Fetch historical logs on mount / agent change
    useEffect(() => {
        let cancelled = false;
        setLogs([]); // Clear on agent change
        const client = new ApiClient(apiPort, authToken);
        client.getLogs(agentId, 30).then(res => {
            if (cancelled)
                return;
            if (Array.isArray(res)) {
                const mapped = res.reverse().map((l) => ({
                    id: l.id?.toString() || `hist-${Math.random()}`,
                    type: mapActionToType(l.action),
                    content: [l.action, l.result, l.thought].filter(Boolean).join(' — '),
                    timestamp: l.timestamp || '',
                }));
                setLogs(mapped);
            }
        }).catch(() => { });
        return () => { cancelled = true; };
    }, [agentId, apiPort, authToken]);
    // Live log streaming via socket — matches actual core events
    useEffect(() => {
        if (!socket)
            return;
        const addLog = (type, content, agent) => {
            if (agent && agent !== agentId && agent !== agentName)
                return;
            setLogs(prev => [...prev, {
                    id: `${type}-${Date.now()}-${Math.random()}`,
                    type,
                    content,
                    timestamp: new Date().toISOString(),
                }].slice(-maxLines));
        };
        // Core emits: agent:thought { agent, thought, timestamp }
        const onThought = (d) => addLog('thought', d.thought, d.agent);
        // Core emits: agent:action { agent, tool, result, timestamp }
        const onAction = (d) => addLog('action', `${d.tool}${d.result ? ': ' + (d.result.length > 100 ? d.result.slice(0, 100) + '...' : d.result) : ''}`, d.agent);
        // Core emits: agent:error { agent, error, timestamp }
        const onError = (d) => addLog('error', d.error, d.agent);
        // Core emits: agent:transaction { agent, type, amount, token, ... }
        const onTx = (d) => addLog('transaction', `${d.type || 'tx'} ${d.amount || ''} ${d.token || ''} ${d.signature ? '(' + d.signature.slice(0, 8) + '...)' : ''}`.trim(), d.agent);
        socket.on('agent:thought', onThought);
        socket.on('agent:action', onAction);
        socket.on('agent:error', onError);
        socket.on('agent:transaction', onTx);
        return () => {
            socket.off('agent:thought', onThought);
            socket.off('agent:action', onAction);
            socket.off('agent:error', onError);
            socket.off('agent:transaction', onTx);
        };
    }, [socket, agentId, agentName, maxLines]);
    const typeColor = (type) => {
        switch (type) {
            case 'thought': return 'yellow';
            case 'action': return 'blue';
            case 'transaction': return 'green';
            case 'error': return 'red';
            default: return 'gray';
        }
    };
    const typeLabel = (type) => {
        switch (type) {
            case 'thought': return 'THOUGHT';
            case 'action': return 'ACTION ';
            case 'transaction': return 'TX     ';
            case 'error': return 'ERROR  ';
            default: return 'INFO   ';
        }
    };
    return (_jsxs(Box, { flexDirection: "column", gap: 1, children: [logs.length === 0 && (_jsx(Text, { dimColor: true, children: "  Waiting for activity..." })), logs.map((log) => {
                const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString('en-US', { hour12: false }) : '';
                return (_jsxs(Box, { gap: 1, children: [_jsx(Text, { dimColor: true, children: time }), _jsx(Text, { color: typeColor(log.type), bold: true, children: typeLabel(log.type) }), _jsx(Text, { dimColor: true, children: log.content.length > 200 ? log.content.slice(0, 200) + '...' : log.content })] }, log.id));
            })] }));
}
/**
 * Map DB log `action` field to a display type.
 */
function mapActionToType(action) {
    if (!action)
        return 'info';
    const a = action.toLowerCase();
    if (a.includes('error'))
        return 'error';
    if (a.includes('invoke') || a.includes('cron') || a.includes('cycle'))
        return 'action';
    if (a.includes('token') || a.includes('usage'))
        return 'info';
    return 'thought';
}
//# sourceMappingURL=LogsView.js.map
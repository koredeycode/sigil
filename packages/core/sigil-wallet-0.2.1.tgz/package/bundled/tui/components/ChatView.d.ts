interface ChatMessage {
    id: number | string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    tools?: string | Array<{
        tool: string;
        result: string;
    }>;
}
interface ChatViewProps {
    singleMessage?: ChatMessage;
    onSubmit?: (val: string) => void;
    isFocused?: boolean;
    sending?: boolean;
    inputOnly?: boolean;
}
export declare function ChatView({ singleMessage, onSubmit, isFocused, sending, inputOnly, }: ChatViewProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=ChatView.d.ts.map
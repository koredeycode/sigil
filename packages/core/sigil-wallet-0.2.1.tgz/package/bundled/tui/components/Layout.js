import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Static, Text, useApp, useInput, useStdout } from 'ink';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useConfig } from '../context/ConfigContext.js';
import { useAgents } from '../hooks/useAgents.js';
import { useSocket } from '../hooks/useSocket.js';
import { ApiClient } from '../lib/api.js';
import { ChatView } from './ChatView.js';
import { LogsView } from './LogsView.js';
import { Splash } from './Splash.js';
// ── Outer Shell: handles splash + delegates to inner view ──────────────────
export function Layout() {
    const [showSplash, setShowSplash] = useState(true);
    const handleSplashDone = useCallback(() => setShowSplash(false), []);
    if (showSplash) {
        return _jsx(Splash, { onDone: handleSplashDone });
    }
    return _jsx(LayoutInner, {});
}
// ── Inner Layout: all the real work ────────────────────────────────────────
function LayoutInner() {
    const { agents, activeAgent, nextAgent } = useAgents();
    const { exit } = useApp();
    const { apiPort, authToken } = useConfig();
    const { socket, connected } = useSocket();
    const { stdout } = useStdout();
    const [messages, setMessages] = useState([]);
    const [sending, setSending] = useState(false);
    const [provider, setProvider] = useState(null);
    const [viewMode, setViewMode] = useState('chat');
    // Bump this to force a full remount of the view (clears Static items)
    const [viewKey, setViewKey] = useState(0);
    const termWidth = stdout?.columns ?? 80;
    const prevAgentRef = useRef(null);
    const hLine = useMemo(() => '─'.repeat(Math.max(1, termWidth - 4)), [termWidth]);
    // Fetch primary provider info (once)
    useEffect(() => {
        if (!authToken)
            return;
        const client = new ApiClient(apiPort, authToken);
        client.getProviders().then(providers => {
            const primary = providers.find((p) => p.is_primary);
            if (primary)
                setProvider({ name: primary.name, model: primary.model });
            else if (providers.length > 0)
                setProvider({ name: providers[0].name, model: providers[0].model });
        }).catch(() => { });
    }, [apiPort, authToken]);
    // Fetch chat history when agent changes
    useEffect(() => {
        if (!activeAgent)
            return;
        if (prevAgentRef.current === activeAgent.id)
            return;
        prevAgentRef.current = activeAgent.id;
        const client = new ApiClient(apiPort, authToken);
        client.getChats(activeAgent.id, 30).then(res => {
            if (Array.isArray(res))
                setMessages(res);
        }).catch(() => { });
    }, [activeAgent, apiPort, authToken]);
    // Socket listeners
    useEffect(() => {
        if (!socket || !activeAgent)
            return;
        const handleMessage = (data) => {
            if (data.agent === activeAgent.name) {
                setMessages(prev => {
                    const exists = prev.some(m => m.id === data.timestamp ||
                        (m.role === data.role && m.content === data.content && Date.now() - Number(m.id) < 1000));
                    if (exists && data.role === 'user')
                        return prev;
                    return [...prev, {
                            id: data.timestamp || Date.now(),
                            role: data.role,
                            content: data.content,
                            tools: data.tools,
                        }].slice(-100);
                });
                if (data.role === 'assistant')
                    setSending(false);
            }
        };
        const addSystem = (prefix, content, agent) => {
            if (agent !== activeAgent.id && agent !== activeAgent.name)
                return;
            setMessages(prev => [...prev, {
                    id: `${prefix}-${Date.now()}`,
                    role: 'system',
                    content: `[${prefix}] ${content}`,
                }].slice(-100));
        };
        const onThought = (d) => addSystem('thought', d.thought, d.agent);
        const onAction = (d) => addSystem('action', d.tool, d.agent);
        const onError = (d) => addSystem('error', d.error, d.agent);
        const onTx = (d) => addSystem('tx', `${d.type || 'transaction'} ${d.amount || ''} ${d.token || ''}`.trim(), d.agent);
        socket.on('chat:message', handleMessage);
        socket.on('agent:thought', onThought);
        socket.on('agent:action', onAction);
        socket.on('agent:error', onError);
        socket.on('agent:transaction', onTx);
        return () => {
            socket.off('chat:message', handleMessage);
            socket.off('agent:thought', onThought);
            socket.off('agent:action', onAction);
            socket.off('agent:error', onError);
            socket.off('agent:transaction', onTx);
        };
    }, [socket, activeAgent]);
    const handleSubmit = useCallback((val) => {
        if (!val.trim() || !socket || !activeAgent)
            return;
        socket.emit('chat:message', { agentId: activeAgent.id, content: val.trim() });
        setSending(true);
    }, [socket, activeAgent]);
    // Keyboard shortcuts
    useInput((input, key) => {
        if (input === 'c' && key.ctrl) {
            exit();
            return;
        }
        if (key.tab && !key.shift) {
            process.stdout.write('\x1B[2J\x1B[H');
            setViewMode(prev => prev === 'chat' ? 'logs' : 'chat');
            setViewKey(k => k + 1);
            return;
        }
        if (key.tab && key.shift) {
            process.stdout.write('\x1B[2J\x1B[H');
            nextAgent();
            prevAgentRef.current = null;
            setMessages([]);
            setViewKey(k => k + 1);
            return;
        }
    });
    if (!activeAgent) {
        return (_jsx(Box, { padding: 1, children: _jsx(Text, { dimColor: true, children: "Waiting for agents to initialize..." }) }));
    }
    const agentIndex = agents.findIndex(a => a.id === activeAgent.id);
    const statusColor = activeAgent.status === 'running' ? 'green' : 'yellow';
    /*
     * The entire view below uses a `key` that changes on agent/view switch.
     * This forces React to unmount and remount, which:
     * 1. Clears Static's internal item list (starts fresh)
     * 2. Combined with clearScreen(), gives a clean slate
     *
     * During normal typing, nothing here changes, so Static items are untouched
     * and only the tiny dynamic area (input + status) re-renders.
     */
    return (_jsxs(Box, { flexDirection: "column", width: "100%", children: [viewMode === 'chat' && (_jsx(Static, { items: messages, children: (msg) => _jsx(ChatView, { singleMessage: msg }, String(msg.id)) })), viewMode === 'logs' && (_jsx(LogsView, { agentId: activeAgent.id, agentName: activeAgent.name, maxLines: 30 })), _jsxs(Box, { paddingX: 2, gap: 2, marginTop: 1, children: [_jsx(Text, { bold: viewMode === 'chat', color: viewMode === 'chat' ? 'white' : 'gray', children: viewMode === 'chat' ? '[Chat]' : ' Chat ' }), _jsx(Text, { bold: viewMode === 'logs', color: viewMode === 'logs' ? 'white' : 'gray', children: viewMode === 'logs' ? '[Logs]' : ' Logs ' }), _jsx(Box, { flexGrow: 1 }), _jsx(Text, { bold: true, color: "magenta", children: activeAgent.name }), provider && (_jsxs(_Fragment, { children: [_jsx(Text, { dimColor: true, children: "\u00B7" }), _jsx(Text, { dimColor: true, children: provider.model })] })), _jsx(Text, { dimColor: true, children: "\u00B7" }), _jsx(Text, { color: statusColor, children: "\u25CF" }), _jsxs(Text, { dimColor: true, children: [" ", activeAgent.status] }), agents.length > 1 && (_jsxs(_Fragment, { children: [_jsx(Text, { dimColor: true, children: " \u00B7" }), _jsxs(Text, { dimColor: true, children: [" ", agentIndex + 1, "/", agents.length] })] }))] }), viewMode === 'chat' && (_jsxs(_Fragment, { children: [_jsx(Box, { paddingX: 2, children: _jsx(Text, { dimColor: true, children: hLine }) }), _jsx(Box, { paddingX: 2, paddingY: 0, children: _jsx(ChatView, { onSubmit: handleSubmit, isFocused: true, sending: sending, inputOnly: true }) })] })), _jsx(Box, { paddingX: 2, children: _jsx(Text, { dimColor: true, children: hLine }) }), _jsxs(Box, { paddingX: 2, children: [_jsxs(Box, { flexGrow: 1, children: [_jsx(Text, { color: "cyan", bold: true, children: "Tab" }), _jsxs(Text, { dimColor: true, children: [": ", viewMode === 'chat' ? 'logs' : 'chat'] }), agents.length > 1 && (_jsxs(_Fragment, { children: [_jsx(Text, { dimColor: true, children: "  |  " }), _jsx(Text, { color: "cyan", bold: true, children: "Shift+Tab" }), _jsx(Text, { dimColor: true, children: ": switch agent" })] })), _jsx(Text, { dimColor: true, children: "  |  " }), _jsx(Text, { color: "red", bold: true, children: "Ctrl+C" }), _jsx(Text, { dimColor: true, children: ": exit" })] }), provider && _jsx(Text, { dimColor: true, children: provider.name })] })] }, viewKey));
}
//# sourceMappingURL=Layout.js.map
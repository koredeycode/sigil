import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
import TextInput from 'ink-text-input';
import { useState } from 'react';
export function CommandPalette({ onExecute, onClose }) {
    const [query, setQuery] = useState('');
    return (_jsxs(Box, { borderStyle: "double", borderColor: "magenta", padding: 1, flexDirection: "column", width: 50, children: [_jsx(Text, { bold: true, children: "Command Palette" }), _jsxs(Box, { marginTop: 1, children: [_jsx(Text, { color: "magenta", children: "\u1433 " }), _jsx(TextInput, { value: query, onChange: setQuery, onSubmit: (val) => {
                            onExecute(val);
                            onClose();
                        }, placeholder: "Type a command..." })] }), _jsx(Box, { marginTop: 1, children: _jsx(Text, { dimColor: true, children: "Examples: /kill, /restart, /clear" }) })] }));
}
//# sourceMappingURL=CommandPalette.js.map
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
export function SettingsPanel() {
    return (_jsxs(Box, { borderStyle: "double", borderColor: "yellow", padding: 1, flexDirection: "column", width: 40, children: [_jsx(Text, { bold: true, underline: true, children: "Settings" }), _jsxs(Box, { flexDirection: "column", marginTop: 1, children: [_jsxs(Text, { children: ["Kill Switch: ", _jsx(Text, { color: "green", children: "OFF" })] }), _jsxs(Text, { children: ["Max Slippage: ", _jsx(Text, { color: "green", children: "1%" })] }), _jsxs(Text, { children: ["Theme: ", _jsx(Text, { color: "cyan", children: "Dark" })] })] }), _jsx(Box, { marginTop: 1, children: _jsx(Text, { dimColor: true, children: "Press Esc to close" }) })] }));
}
//# sourceMappingURL=SettingsPanel.js.map
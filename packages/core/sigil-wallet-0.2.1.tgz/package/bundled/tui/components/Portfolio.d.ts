import { Agent } from '../hooks/useAgents.js';
interface PortfolioProps {
    activeAgent: Agent | null;
}
export declare function Portfolio({ activeAgent }: PortfolioProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=Portfolio.d.ts.map
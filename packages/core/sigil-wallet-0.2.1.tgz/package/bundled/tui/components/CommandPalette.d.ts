interface CommandPaletteProps {
    onExecute: (cmd: string) => void;
    onClose: () => void;
}
export declare function CommandPalette({ onExecute, onClose }: CommandPaletteProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CommandPalette.d.ts.map
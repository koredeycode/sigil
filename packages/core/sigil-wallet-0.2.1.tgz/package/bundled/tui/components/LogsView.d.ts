interface LogsViewProps {
    agentId: string;
    agentName: string;
    maxLines?: number;
}
export declare function LogsView({ agentId, agentName, maxLines }: LogsViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=LogsView.d.ts.map
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Box, Text } from 'ink';
export function AgentSelector({ activeAgent, agents }) {
    if (!activeAgent) {
        return (_jsxs(Box, { borderStyle: "round", borderColor: "cyan", paddingX: 1, children: [_jsx(Text, { children: "No agents found. Run " }), _jsx(Text, { bold: true, color: "yellow", children: "sigil agent create" })] }));
    }
    return (_jsxs(Box, { borderStyle: "round", borderColor: "cyan", paddingX: 1, children: [_jsx(Text, { children: "Agent: " }), _jsx(Text, { bold: true, color: "green", children: activeAgent.name }), _jsxs(Text, { dimColor: true, children: [" (", activeAgent.status, ")"] }), _jsx(Text, { children: " | " }), _jsx(Text, { dimColor: true, children: "Use \u2190 \u2192 to switch" })] }));
}
//# sourceMappingURL=AgentSelector.js.map